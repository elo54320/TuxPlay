angular.module('app.controllers-jeux', [])

.controller('rechercheJeuxCtrl', function($scope, jeuRepository, $state, $localStorage) {
 jeuRepository.list().then(function(response) {
 	console.log(response.data);
 	$scope.jeux = response.data;
 }, function(error) {
 	 	console.log("oups");
 })


	$scope.charger = function(nom) {
		console.log("Dans fonction Charger");
		jeuRepository.charger(nom).then(function (response){
			if (response.data.length > 0) {
				var jeu  = response.data[0];
				$localStorage.setObject('jeu', jeu);
				$state.go('jeu');
			} else {

			}
		});
	};

}
)



.controller('jeuCtrl', function($scope, $localStorage, $authJeu, jeuRepository) {
// C'est ici qu'on affichera les informations du jeu qui a été choisi par l'utilisateur 
console.log($authJeu.isLogged());
$scopeJeu=$localStorage.getObject('jeu');

$scope.image  = "\\img\\jeu\\"+$scopeJeu.nom_image+".jpg";
$scope.jeu=$localStorage.getObject('jeu');
console.log($scope.image);
// Les informations on été affichés on supprime l'objet jeu
 })

.controller('gestionJeuxCtrl', function($scope) {

})
.controller('editerJeuCtrl', function($scope) {

});

