angular.module('app.controllers-parties', [])

.controller('recherchePartiesCtrl', function ($scope, partieRepository, $state, $localStorage) {
 partieRepository.list().then(function(response) {
 	console.log(response.data);
 	$scope.parties = response.data;
 }, function(error) {
 	 	console.log("oups");
 })


	$scope.charger = function(nom, ville, jeu) {

		console.log("Dans fonction Charger");
		console.log(nom+" "+ville+" "+jeu);
		partieRepository.chargerPartie(nom, ville, jeu).then(function(response){
			console.log(response.data.length);
			if (response.data.length > 0) {
				var partie  = response.data[0];
				$localStorage.setObject('partie', partie);
				$state.go('partie');
			}
		});
	};

})


.controller('partieCtrl', function($scope, $localStorage, $authPartie, partieRepository) {
// C'est ici qu'on affichera les informations de la partie qui a été choisie par l'utilisateur 
console.log($authPartie.isLogged());
$scopePartie=$localStorage.getObject('partie');

$scope.partie=$localStorage.getObject('partie');
//gerer les participations

	$scope.participer = function(nameCreator, name, ville, jeu) {
		console.log("data²ns fonction Participer");
		$scope.user=$localStorage.getObject('user');
		if(nameCreator!=$scope.user.pseudo){
			console.log("Pas même user"); 
			// Verifie si l'utilisateur est déjà inscrit ou pas 
			partieRepository.verifParticiper($scope.user.pseudo, nameCreator, name, ville, jeu).then(function(response){
				console.log("Ok");
				if (response.data.length == 0) {
					$scope.participant={}
					$scope.participant.pseudo=$scope.user.pseudo
					$scope.participant.nom_partie=name
					$scope.participant.ville=ville
					$scope.participant.jeu=jeu
					$scope.participant.pseudo_creator=nameCreator
					console.log("pas inscrit");
					//Normalement utilisateur pas inscrit
					
						//ajoute une personne
						if($scope.partie.nbpersMax>$scope.partie.nbpersInsc){
							console.log($scope.partie.nbpersInsc);
							$scope.partie.nbpersInsc=$scope.partie.nbpersInsc+1;
							console.log($scope.partie.nbpersInsc);
							partieRepository.update($scope.partie._id, $scope.partie).then(function (response){
								partieRepository.creaParticipant($scope.participant).then(function (response){
									alert("Vous êtes bien inscrit");});
							});
							
						}else{
							alert('Il y a trop de monde désolé');
						}
						
						
					
				}
			});
		}
		
	};

// Les informations on été affichés on supprime l'objet partie
})
.controller('creationPartieCtrl', function($scope) {

})



.controller('editerPartieCtrl', function($scope, $state, $localStorage, partieRepository) {
$scope.partie=$localStorage.getObject('partie');

$scope.editPartie = function(){
	console.log("La partie : ");
	console.log($scope.partie);
	partieRepository.update($scope.partie._id, $scope.partie).then(function (response){
		$localStorage.setObject('partie', $scope.partie);
			console.log("Ok modif");
			console.log($scope.partie);
			$state.go('profilJoueur');
		});


}


})