angular.module('app.controllers-user', [])
  
.controller('tuxPlayCtrl', function($scope) {

})
   
.controller('connexionCtrl', function($scope, $state, $localStorage, userRepository, $auth) {
	//console.log($auth.isLogged());
	$scope.user = {};
	$scope.connect = function() {
		console.log("Dans fonction");
		console.log($scope.user);
		userRepository.connect($scope.user.pseudo, $scope.user.password).then(function (response){
			if (response.data.length > 0) {
				var user  = response.data[0];
				$localStorage.setObject('user', user);
				$state.go('profilJoueur');
			}
		});
	};
})
   
.controller('inscriptionCtrl', function($scope, $state, userRepository) {
	$scope.user = {};
	$scope.create = function() {
		console.log("Dans fonction");
		console.log($scope.user);
		userRepository.create($scope.user).then(function (response){
			$state.go('profilJoueur');
		});

	};

$scope.data = {
    multipleSelect: [],
    options: {
    	'Aloha': 'Aloha',
		'Antilles' : 'Antilles',
		'Asiatique' : 'Asiatique',
		'Asie' : 'Asie',
		'Asterix' : 'Asterix',
		'Avatar' : 'Avatar',
		'Baggy' : 'Baggy',
		'Balance' : 'Balance',
		'Batman' : 'Batman',
		'Becassine' : 'Becassine',
		'Bélier' : 'Bélier',
		'Billard' : 'Billard',
		'Blanche neige' : 'Blanche neige',
		'Bugs Bunny' : 'Bugs Bunny',
		'Cancer' : 'Cancer',
		'Capricorne' : 'Capricorne',
		'Captain America':'Captain America',
		'Caribou':'Caribou',
		'Casimir':'Casimir',
		'Cesar':'Cesar',
		'Coco':'Coco',
		'Cupidon':'Cupidon',
		'Cyborg':'Cyborg',
		'Daisy':'Daisy',
		'Danseuse':'Danseuse',
		'Diable':'Diable',
		'Diddle':'Diddle',
		'Diva':'Diva',
		'Dragon':'Dragon',
		'Fluo':'Fluo',
		'Gandalf':'Gandalf',
		'Gémeaux':'Gémeaux',
		'Gentleman':'Gentleman',
		'Indienne':'Indienne',
		'Kenpachi':'Kenpachi',
		'Lapin vert':'Lapin vert',
		'Lara Croft':'Lara Croft',
		'Liban':'Liban',
		'Liloo':'Liloo',
		'Lion':'Lion',
		'Lulu':'Lulu',
		'Magritte':'Magritte',
		'Maid':'Maid',
		'Manga':'Manga',
		'Marsupilami':'Marsupilami',
		'Metropole':'Metropole',
		'Milka':'Milka',
		'Momie':'Momie',
		'Newcastle':'Newcastle',
		'Nucléaire':'Nucléaire',
		'Obélix':'Obélix',
		'Pere Noel':'Pere Noel',
		'Perrier':'Perrier',
		'Platre':'Platre',
		'Plongeur':'Plongeur',
		'Pocahontas':'Pocahontas',
		'Poisson':'Poisson',
		'Polynesie':'Polynesie',
		'Prehistorique':'Prehistorique',
		'Professeur':'Professeur',
		'Psychedelique':'Psychedelique',
		'Reunion':'Reunion',
		'Rugbyman':'Rugbyman',
		'Sagitaire':'Sagitaire',
		'Samourai':'Samourai',
		'Sasuke':'Sasuke',
		'Scorpion':'Scorpion',
		'Serrure':'Serrure',
		'Sony':'Sony',
		'Sparta':'Sparta',
		'Spiderman':'Spiderman',
		'St Nicolas':'St Nicolas',
		'Sud':'Sud',
		'Sumo':'Sumo',
		'Superman':'Superman',
		'Taureau':'Taureau',
		'Teletubbies':'Teletubbies',
		'Totoro':'Totoro',
		'Verseau':'Verseau',
		'Vierge':'Vierge',
    },

   };

   userRepository.list();
	$scope.image = "\\img\\tux\\Tux.png";
	$scope.change = function(){
		console.log($scope.user.tux);
		var chemin = '\\img\\tux\\';
		$scope.user.image=$scope.user.tux;
		$scope.image = chemin+$scope.user.tux+".png";
	};
})
   
.controller('contactCtrl', function($scope) {

})
   
.controller('quiSommesNousCtrl', function($scope) {

})
   

.controller('profilJoueurCtrl', function($scope, $auth, $localStorage, $state, partieRepository, $window) {
	$scope.parties = {};
	$scope.user=$localStorage.getObject('user');
	console.log($scope.user.pseudo);
	partieRepository.profil($scope.user.pseudo).then(function(data){
		$scope.parties = data;

		console.log($scope.parties.data[0]);
	}, function(error){})


		$scope.chargerPartie = function(name, user, date) {
		console.log("Dans fonction Charger partie");
		partieRepository.charger(name, user, date).then(function (response){
			if (response.data.length > 0) {
				console.log("OK OK")
				var partie  = response.data[0];
				$localStorage.setObject('partie', partie);
				$state.go('editerPartie');
			} else {

			}
		});
	};


	$scope.deconnect = function() {
		console.log("Dans fonction pour la deconnexion");
		$localStorage.setObject('user', null);
		console.log($localStorage.getObject('user'));
		$window.location.href = '/';
	};

	$scope.user=$localStorage.getObject('user');
	$scope.tux  = "\\img\\tux\\"+$scope.user.tux+".png";


	$scope.modifProfil = function(){
		if($auth.isLogged){
			console.log("OK"); 
			$state.go('editerProfil');
		}
	}
})
   
.controller('editerProfilCtrl', function($scope, $state, $localStorage, userRepository) {
$scope.user=$localStorage.getObject('user');

$scope.edit = function(){
	userRepository.update($scope.user._id, $scope.user).then(function (response){
		$localStorage.setObject('user', $scope.user);
			console.log("Ok modif");
			console.log($scope.user);
			$state.go('profilJoueur');
		});


}


$scope.data = {
    multipleSelect: [],
    options: {
    	'Aloha': 'Aloha',
		'Antilles' : 'Antilles',
		'Asiatique' : 'Asiatique',
		'Asie' : 'Asie',
		'Asterix' : 'Asterix',
		'Avatar' : 'Avatar',
		'Baggy' : 'Baggy',
		'Balance' : 'Balance',
		'Batman' : 'Batman',
		'Becassine' : 'Becassine',
		'Bélier' : 'Bélier',
		'Billard' : 'Billard',
		'Blanche neige' : 'Blanche neige',
		'Bugs Bunny' : 'Bugs Bunny',
		'Cancer' : 'Cancer',
		'Capricorne' : 'Capricorne',
		'Captain America':'Captain America',
		'Caribou':'Caribou',
		'Casimir':'Casimir',
		'Cesar':'Cesar',
		'Coco':'Coco',
		'Cupidon':'Cupidon',
		'Cyborg':'Cyborg',
		'Daisy':'Daisy',
		'Danseuse':'Danseuse',
		'Diable':'Diable',
		'Diddle':'Diddle',
		'Diva':'Diva',
		'Dragon':'Dragon',
		'Fluo':'Fluo',
		'Gandalf':'Gandalf',
		'Gémeaux':'Gémeaux',
		'Gentleman':'Gentleman',
		'Indienne':'Indienne',
		'Kenpachi':'Kenpachi',
		'Lapin vert':'Lapin vert',
		'Lara Croft':'Lara Croft',
		'Liban':'Liban',
		'Liloo':'Liloo',
		'Lion':'Lion',
		'Lulu':'Lulu',
		'Magritte':'Magritte',
		'Maid':'Maid',
		'Manga':'Manga',
		'Marsupilami':'Marsupilami',
		'Metropole':'Metropole',
		'Milka':'Milka',
		'Momie':'Momie',
		'Newcastle':'Newcastle',
		'Nucléaire':'Nucléaire',
		'Obélix':'Obélix',
		'Pere Noel':'Pere Noel',
		'Perrier':'Perrier',
		'Platre':'Platre',
		'Plongeur':'Plongeur',
		'Pocahontas':'Pocahontas',
		'Poisson':'Poisson',
		'Polynesie':'Polynesie',
		'Prehistorique':'Prehistorique',
		'Professeur':'Professeur',
		'Psychedelique':'Psychedelique',
		'Reunion':'Reunion',
		'Rugbyman':'Rugbyman',
		'Sagitaire':'Sagitaire',
		'Samourai':'Samourai',
		'Sasuke':'Sasuke',
		'Scorpion':'Scorpion',
		'Serrure':'Serrure',
		'Sony':'Sony',
		'Sparta':'Sparta',
		'Spiderman':'Spiderman',
		'St Nicolas':'St Nicolas',
		'Sud':'Sud',
		'Sumo':'Sumo',
		'Superman':'Superman',
		'Taureau':'Taureau',
		'Teletubbies':'Teletubbies',
		'Totoro':'Totoro',
		'Verseau':'Verseau',
		'Vierge':'Vierge',
    },

   };
	$scope.image = "\\img\\tux\\Tux.png";
	$scope.change = function(){
		console.log($scope.user.tux);
		var chemin = '\\img\\tux\\';
		$scope.user.image=$scope.user.tux;
		$scope.image = chemin+$scope.user.tux+".png";
		console.log($scope.image);
	};
})




   

   

   

   

 