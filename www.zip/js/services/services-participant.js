angular.module('app.services-participant', [])

.provider('participantRepository', function() {
  this.$get = function($http) {

    return {
      list: function (){
        return $http.get('https://tuxplay-e050.restdb.io/rest/participant');
      },
      find: function (id) {
        return $http.get('https://tuxplay-e050.restdb.io/rest/participant'+'/'+id)
      },
      create: function (data) {
        return $http.post('https://tuxplay-e050.restdb.io/rest/participant', data);
      },
      update: function (id, data) {
        return $http.post('https://tuxplay-e050.restdb.io/rest/participant'+'/'+id, data);
      },
      delete: function (id) {
        return $http.delete('https://tuxplay-e050.restdb.io/rest/participant'+"/"+id);
      }
    };
  };
})


/*
.provider('$authPartie', function() {
  this.$get = function($localStorage) {
      return {
        isLogged: function () {
          var partie = $localStorage.getObject('partie');
          return 'nom' in partie; 
        }
      }
    }
});
*/