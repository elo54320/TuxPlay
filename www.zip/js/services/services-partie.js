angular.module('app.services-partie', [])

.provider('partieRepository', function() {
  this.$get = function($http) {

    return {
      list: function (){
        return $http.get('https://tuxplay-e050.restdb.io/rest/partie');
      },
      find: function (id) {
        return $http.get('https://tuxplay-e050.restdb.io/rest/partie'+'/'+id)
      },
      chargerPartie: function(nom, ville, jeu){
        //local storage : sauvegarder les données de l'utilisateur
        var query = JSON.stringify({"name":nom, "ville_partie":ville, "jeu_nom":jeu});
        return $http.get('https://tuxplay-e050.restdb.io/rest/partie?q='+query+'&max=1');
      },
      charger: function(name, pseudo, date){
        //local storage : sauvegarder les données de l'utilisateur
        var query = JSON.stringify({"name":name, "user_name":pseudo, "date_partie":date});
        return $http.get('https://tuxplay-e050.restdb.io/rest/partie?q='+query+'&max=1');
      },
      profil: function(nom){
        var query = JSON.stringify({"user_name":nom});
        console.log(nom);
        return $http.get('https://tuxplay-e050.restdb.io/rest/partie?q='+query);
      },
      create: function (data) {
        return $http.post('https://tuxplay-e050.restdb.io/rest/partie', data);
      },
      creaParticipant: function(data){
        return $http.post('https://tuxplay-e050.restdb.io/rest/participant', data);
      },
      update: function (id, data) {
        return $http.get('https://tuxplay-e050.restdb.io/rest/partie'+'/'+id, data);
      },
      delete: function (id) {
        return $http.delete('https://tuxplay-e050.restdb.io/rest/partie'+"/"+id);
      },
      verifParticiper: function(pseudo, pseudo_creator, nom, ville, jeu){
        var query = JSON.stringify({"name":nom,"pseudo_creator":pseudo_creator, "user_name":pseudo, "ville_partie":ville, "jeu_nom":jeu});
        return $http.get('https://tuxplay-e050.restdb.io/rest/partie?q='+query);
      }
    };
  };
})



.provider('$authPartie', function() {
  this.$get = function($localStorage) {
      return {
        isLogged: function () {
          var partie = $localStorage.getObject('partie');
          return 'nom' in partie; 
        }
      }
    }
});
