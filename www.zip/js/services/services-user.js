angular.module('app.services-user', [])

.provider('userRepository', function() {
  this.$get = function($http) {

    return {
      list: function (){
        return $http.get('https://tuxplay-e050.restdb.io/rest/user');
      },
      find: function (id) {
        return $http.get('https://tuxplay-e050.restdb.io/rest/user'+'/'+id);
      },
      connect: function(pseudo, mdp){
        //local storage : sauvegarder les données de l'utilisateur
        var query = JSON.stringify({"pseudo":pseudo, "password":mdp});
        return $http.get('https://tuxplay-e050.restdb.io/rest/user?q='+query+'&max=1');
      },
      create: function (data) {
        return $http.post('https://tuxplay-e050.restdb.io/rest/user', data);
      },
      update: function (id, data) {
        return $http.get('https://tuxplay-e050.restdb.io/rest/user'+'/'+id, data);
      },
      delete: function (id) {
        return $http.delete('https://tuxplay-e050.restdb.io/rest/user'+"/"+id);
      }
    };
  };
})

.provider('$auth', function() {
  this.$get = function($localStorage) {
      return {
        isLogged: function () {
          var user = $localStorage.getObject('user');
          return 'mail' in user; 
        }
      }
    }
})
;
