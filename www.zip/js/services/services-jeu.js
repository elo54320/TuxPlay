angular.module('app.services-jeu', [])

.provider('jeuRepository', function() {
  this.$get = function($http) {

    return {
      list: function (){
        return $http.get('https://tuxplay-e050.restdb.io/rest/jeu');
      },
      find: function (id) {
        return $http.get('https://tuxplay-e050.restdb.io/rest/jeu'+'/'+id)
      },
      charger: function(nom){
        //local storage : sauvegarder les donné de l'utilisateur
        console.log(nom);

        var query = JSON.stringify({"nom_jeu":nom});
        return $http.get('https://tuxplay-e050.restdb.io/rest/jeu?q='+query+'&max=1');
      },
      create: function (data) {
        return $http.post('https://tuxplay-e050.restdb.io/rest/jeu', data);
      },
      update: function (id, data) {
        return $http.post('https://tuxplay-e050.restdb.io/rest/jeu'+'/'+id, data);
      },
      delete: function (id) {
        return $http.delete('https://tuxplay-e050.restdb.io/rest/jeu'+"/"+id);
      }
    };
  };
})

.provider('$authJeu', function() {
  this.$get = function($localStorage) {
      return {
        isLogged: function () {
          var jeu = $localStorage.getObject('jeu');
          return 'nom_jeu' in jeu; 
        }
      }
    }
})
;

