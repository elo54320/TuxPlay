angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    
  

      .state('tuxPlay', {
    url: '/accueil',
    templateUrl: 'templates/tuxPlay.html',
    controller: 'tuxPlayCtrl'
  })

  .state('connexion', {
    url: '/connexion',
    templateUrl: 'templates/connexion.html',
    controller: 'connexionCtrl'
  })

  .state('inscription', {
    url: '/inscription',
    templateUrl: 'templates/inscription.html',
    controller: 'inscriptionCtrl'
  })

  .state('contact', {
    url: '/contact',
    templateUrl: 'templates/contact.html',
    controller: 'contactCtrl'
  })

  .state('quiSommesNous', {
    url: '/quiSommesNous',
    templateUrl: 'templates/quiSommesNous.html',
    controller: 'quiSommesNousCtrl'
  })

  .state('rechercheJeux', {
    url: '/rechercheJeux',
    templateUrl: 'templates/rechercheJeux.html',
    controller: 'rechercheJeuxCtrl'
  })

  .state('rechercheParties', {
    url: '/rechercheParties',
    templateUrl: 'templates/rechercheParties.html',
    controller: 'recherchePartiesCtrl'
  })

  .state('jeu', {
    url: '/jeu',
    templateUrl: 'templates/jeu.html',
    controller: 'jeuCtrl'
  })

  .state('partie', {
    url: '/partie',
    templateUrl: 'templates/partie.html',
    controller: 'partieCtrl'
  })

  .state('profilJoueur', {
    url: '/profilJoueur',
    templateUrl: 'templates/profilJoueur.html',
    controller: 'profilJoueurCtrl'
  })

  .state('editerProfil', {
    url: '/editerProfil',
    templateUrl: 'templates/editerProfil.html',
    controller: 'editerProfilCtrl'
  })

  .state('creationPartie', {
    url: '/creationPartie',
    templateUrl: 'templates/creationPartie.html',
    controller: 'creationPartieCtrl'
  })

  .state('gestionJeux', {
    url: '/gestionJeux',
    templateUrl: 'templates/gestionJeux.html',
    controller: 'gestionJeuxCtrl'
  })

  .state('editerPartie', {
    url: '/editerPartie',
    templateUrl: 'templates/editerPartie.html',
    controller: 'editerPartieCtrl'
  })

  .state('editerJeu', {
    url: '/editerJeu',
    templateUrl: 'templates/editerJeu.html',
    controller: 'editerJeuCtrl'
  })

$urlRouterProvider.otherwise('/accueil')

  

});